<?php

use Spryker\Shared\Log\LogConstants;
use Spryker\Shared\Queue\QueueConstants;
use Spryker\Shared\Propel\PropelConstants;
use Spryker\Shared\Mail\MailConstants;
use Spryker\Shared\ZedRequest\ZedRequestConstants;
use Spryker\Shared\HealthCheck\HealthCheckConstants;
use Spryker\Shared\Event\EventConstants;
use Monolog\Logger;

/* Logging */

$stderr = fopen('php://stderr', 'w');

$config[LogConstants::LOG_FILE_PATH] = $stderr;
$config[EventConstants::LOG_FILE_PATH] = $stderr;
$config[QueueConstants::QUEUE_WORKER_OUTPUT_FILE_NAME] = $stderr;
$config[PropelConstants::LOG_FILE_PATH] = $stderr;

$config[LogConstants::LOG_FILE_PATH_YVES] = $stderr;
$config[LogConstants::LOG_FILE_PATH_ZED] = $stderr;
$config[LogConstants::LOG_FILE_PATH_GLUE] = $stderr;

$config[LogConstants::EXCEPTION_LOG_FILE_PATH_YVES] = $stderr;
$config[LogConstants::EXCEPTION_LOG_FILE_PATH_ZED] = $stderr;
$config[LogConstants::EXCEPTION_LOG_FILE_PATH_GLUE] = $stderr;
/* End Logging */


/*
$config[MailConstants::SMTP_HOST]       = getenv('SPRYKER_SMTP_HOST');
$config[MailConstants::SMTP_PORT]       = getenv('SPRYKER_SMTP_PORT');
$config[MailConstants::SMTP_ENCRYPTION] = getenv('SPRYKER_SMTP_ENCRYPTION');
$config[MailConstants::SMTP_AUTH_MODE]  = getenv('SPRYKER_SMTP_AUTH_MODE');
$config[MailConstants::SMTP_USERNAME]   = getenv('SPRYKER_SMTP_USERNAME');
$config[MailConstants::SMTP_PASSWORD]   = getenv('SPRYKER_SMTP_PASSWORD');
*/

//$config[ZedRequestConstants::ZED_API_SSL_ENABLED] = getenv("SPRYKER_SSL_ENABLED");
$config[HealthCheckConstants::HEALTH_CHECK_ENABLED] = (bool)getenv("SPRYKER_HEALTH_CHECK_ENABLED");
