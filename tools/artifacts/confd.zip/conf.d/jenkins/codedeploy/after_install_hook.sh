#!/bin/bash
set -euxo pipefail
env
pwd

mkdir -p /opt/jenkins

if [ ! -f /opt/jenkins/docker-compose.yml ]; then
  ln -s /latest_deploy_artifacts/docker-compose.yml /opt/jenkins/docker-compose.yml
fi

if [ ! -f /sbin/docker-compose ]; then
  COMPOSE_VERSION="1.29.2"
  # Install docker-compose
  HTTP_CODE=$(curl -sL https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m) -o /sbin/docker-compose -w "%{http_code}\n")
  test ${HTTP_CODE} -ne 200 && ( rm -f /sbin/docker-compose; exit 1;) || chmod +x /sbin/docker-compose
fi

docker-compose -f /opt/jenkins/docker-compose.yml pull
docker-compose -f /opt/jenkins/docker-compose.yml down --remove-orphans
docker-compose -f /opt/jenkins/docker-compose.yml up -d

docker images -f "dangling=true" -q | xargs --no-run-if-empty docker rmi -f

#cleanup old jenkins images
CUR_IMG_TAG=$(docker ps -f name=jenkins_scheduler --format "{{.Image}}" | awk -F ":" '{print $2}')
CUR_IMG_ID=$(docker images --filter="reference=*/*${CUR_IMG_TAG}" --format={{.ID}})
if [[ $(docker images --filter="reference=*/*-jenkins" --format={{.ID}} | grep -v ${CUR_IMG_ID}) ]]; then
  docker rmi $(docker images --filter="reference=*/*-jenkins" --format={{.ID}} | grep -v ${CUR_IMG_ID})
fi
