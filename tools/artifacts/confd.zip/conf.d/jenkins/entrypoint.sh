#!/bin/bash

mkdir -p ~/.jenkins/updates
mkdir -p ~/.jenkins/plugins

test -f ~/.jenkins/jenkins.model.JenkinsLocationConfiguration.xml || envsubst < /opt/jenkins.model.JenkinsLocationConfiguration.xml > ~/.jenkins/jenkins.model.JenkinsLocationConfiguration.xml

cp -r /usr/share/jenkins/ref/plugins/* /root/.jenkins/plugins/

trap 'echo "Trapping SIGTERM"; kill ${pid}; exit 0;' SIGTERM
trap 'echo "Trapping SIGQUIT"; kill ${pid}; exit 0;' SIGQUIT
java ${JAVA_OPTS} -jar /usr/share/jenkins/jenkins.war ${JENKINS_OPTS} & pid=$!

wait ${pid}